# -*- coding: utf-8 -*-
"""
Created on Sun Mar 15 11:35:50 2015

@author: KasturiSarang
"""
import scipy
from scipy.optimize import leastsq
import numpy as np
import absorption 
from absorption.Compounds import h2o as h2o
from absorption.Compounds import ch4 as ch4
from absorption.Compounds import co2 as co2
from absorption.Compounds import h2s as h2s
Compounds={'co2':co2,'ch4':ch4,'h2s':h2s,'h2o':h2o}
Fvin={'co2':50.0,'ch4':50.0,'h2s':2.0,'h2o':0.0}
Flin={'co2':0.0,'ch4':0.0,'h2s':0.0,'h2o':100.0}
#from absorption.Compounds import h2o
#from absorption.Compounds import ch4
#from absorption.Compounds import co2
#from absorption.Compounds import h2s
import data

class Exam:
    def __init__(self):
        self.Compounds={'co2':co2,'ch4':ch4,'h2s':h2s,'h2o':h2o}
        self.Fvin={'co2':50.0,'ch4':50.0,'h2s':2.0,'h2o':0.0}
        self.Flin={'co2':0.0,'ch4':0.0,'h2s':0.0,'h2o':100.0}
        self.H=data.H
        self.P=data.P
        self.n=data.n
        self.S=data.S
        self.Tvin=data.Tvin
        self.Tlin=data.Tlin
        self.rhoL=data.rhoL
        self.kla=data.kla
        self.kga=data.kga
        

    def set_grid(self):
        n=self.n
        self.dz=self.H/((self.n)-1)
        self.Fvco2guess=scipy.ones(n)*self.Fvin['co2']
        print self.Fvco2guess
        self.Fvh2sguess=scipy.ones(n)*self.Fvin['h2s']
        self.Fvch4guess=scipy.ones(n)*self.Fvin['ch4']
        self.Fvh2oguess=scipy.ones(n)*self.Fvin['h2o']
        self.Flh2oguess=scipy.ones(n)*self.Flin['h2o']
        self.Flco2guess=scipy.ones(n)*self.Flin['co2']
        self.Flch4guess=scipy.ones(n)*self.Flin['ch4']
        self.Flh2sguess=scipy.ones(n)*self.Flin['h2s']
        self.Tguess=scipy.ones(n)*self.Tvin    
        self.guess=scipy.concatenate((self.Fvco2guess,self.Fvh2sguess, self.Fvch4guess,self.Fvh2oguess,self.Tguess))
        print "guess"
        print self.guess
        self.n=len(self.guess)/5.0
        print"n"
        print self.n
   
        
    def solve(self):
        guess=(self.guess)
        self.n=len(self.guess)/5
        self.soln=scipy.optimize.leastsq(residuals,guess,args=(self))[0]
       
        self.Fvco2soln=self.soln[:self.n]
        self.Fvh2ssoln=self.soln[self.n:2*self.n]
        self.Fvch4soln=self.soln[2*self.n:3*self.n]
        self.Fvh2osoln=self.soln[3*self.n:4*self.n]
        self.Tsoln=self.soln[4*self.n:]

        print "Fvco2soln"
        print self.Fvco2soln
        print "Fvch4soln"
        print self.Fvch4soln
        print "Fvh2ssoln"
        print self.Fvh2ssoln
        print "Fvh2osoln"
        print self.Fvh2osoln
        print "T"
        print self.Tsoln
        
        #print self.Hvsoln
        #print self.Hlsoln

def residuals(ARR,obj):
    n=obj.n
    P=obj.P
    dz=obj.dz
    S=obj.S
    rhoL=obj.rhoL
    kla=obj.kla
    kga=obj.kga
    #inlet enthalpies are known

    #make array
    Fvco2=ARR[:n]
    Fvh2s=ARR[n:2*n]
    Fvch4=ARR[2*n:3*n]
    Fvh2o=ARR[3*n:4*n]
    T=ARR[4*n:]
    
    #assign values
    
    #inlet-liquid and vapor
    Fvch4in=obj.Fvin['ch4']
    Flch4in=obj.Flin['ch4']
    Fvco2in=obj.Fvin['co2']
    Flco2in=obj.Flin['co2']
    Fvh2sin=obj.Fvin['h2s']
    Flh2sin=obj.Flin['h2s']
    Fvh2oin=obj.Fvin['h2o']
    Flh2oin=obj.Flin['h2o']
    
    #outlet
    #outlet liquid flow rates are unknown
    Fvch4out=Fvch4[-1]
    Fvco2out=Fvco2[-1]
    Fvh2sout=Fvh2s[-1]
    Fvh2oout=Fvh2o[-1] #water is also getting evaporated
    
#    for i in range(len(obj.Compounds)):
#        key=obj.Compounds.keys[][i]
#        dict_Fv[key]=ARR[i*n:(i+1)*n]
    #total vapor flow rate
    Fv=Fvch4+Fvco2+Fvh2s+Fvh2o
    
    
    #write liquid flow rates interms of vapr flow rates
    Flch4=Fvch4+Flch4in-Fvch4out
    Flco2=Fvco2+Flco2in-Fvco2out
    Flh2s=Fvh2s+Flh2sin-Fvh2sout
    Flh2o=Fvh2o+Flh2oin-Fvh2oout
    
    #Total liquid flow rate
    Fl=Flch4+Flco2+Flh2s+Flh2o
    
    #mole fractions
    #in vapor phase
    ych4=Fvch4/Fv
    yco2=Fvco2/Fv
    yh2s=Fvh2s/Fv
    yh2o=Fvh2o/Fv
    
    #in liquid phase
    xch4=Flch4/Fl
    xco2=Flco2/Fl
    xh2s=Flh2s/Fl
    xh2o=Flh2o/Fl
    
    #driving forces for vapor phase
    #assume density of liquid remains constant that of water since very small amounts of gases
    #are getting absorbed
    drv_ch4=P*ych4-obj.Compounds['ch4'].kH(T)*xch4*rhoL
    drv_co2=P*yco2-obj.Compounds['co2'].kH(T)*xco2*rhoL
    drv_h2s=P*yh2s-obj.Compounds['h2s'].kH(T)*xh2s*rhoL
    drv_h2o=P*yh2o-obj.Compounds['h2o'].Psat(T)*xh2o
    
    #transfer coefficients
    #kla and kga are assumed to be constant for all compounds and also independent of temp
    Kco2=((1/kla)+(obj.Compounds['co2'].kH(T))/kga)**-1
    Kch4=((1/kla)+(obj.Compounds['ch4'].kH(T))/kga)**-1
    Kh2s=((1/kla)+(obj.Compounds['h2s'].kH(T))/kga)**-1
    Kh2o=kga
    
    #Roverall
    Rch4=drv_ch4*Kch4
    Rco2=drv_co2*Kco2
    Rh2s=drv_h2s*Kh2s
    Rh2o=drv_h2o*Kh2o
    
    #finite difference
    dF_ch4=np.gradient(Fvch4,dz)
    dF_co2=np.gradient(Fvco2,dz)
    dF_h2s=np.gradient(Fvh2s,dz)
    dF_h2o=np.gradient(Fvh2o,dz)
    
    #mass residuals
    errch4=dF_ch4+(Rch4*S)
    errco2=dF_co2+(Rco2*S)
    errh2s=dF_h2s+(Rh2s*S)
    errh2o=dF_h2o+(Rh2o*S)
    
    #enthalpy calculations
    #liquid phase
    Hlch4=scipy.array([obj.Compounds['ch4'].Hl(x) for x in T])
    Hl_ch4=Flch4*Hlch4
    
    Hlco2=scipy.array([obj.Compounds['co2'].Hl(x) for x in T]) 
    Hl_co2=Flco2*Hlco2
    
    Hlh2s=scipy.array([obj.Compounds['h2s'].Hl(x) for x in T]) 
    Hl_h2s=Flh2s*Hlh2s
    
    Hlh2o=scipy.array([Compounds['h2o'].Hl(x) for x in T]) 
    Hl_h2o=Flh2o*Hlh2o
    
    #vapor phase
    Hvco2=scipy.array([obj.Compounds['co2'].Hv(x) for x in T]) 
    Hv_co2=Fvco2*Hvco2
    
    Hvch4=scipy.array([obj.Compounds['ch4'].Hv(x) for x in T]) 
    Hv_ch4=Fvch4*Hvch4
    
    Hvh2s=scipy.array([obj.Compounds['h2s'].Hv(x) for x in T]) 
    Hv_h2s=Fvh2s*Hvh2s
    
    Hvh2o=scipy.array([Compounds['h2o'].Hv(x) for x in T]) 
    Hv_h2o=Fvh2o*Hvh2o
    
    #total enthalpy in both phases
    Hv=Hv_ch4+Hv_co2+Hv_h2s+Hv_h2o
    Hl=Hl_ch4+Hl_co2+Hl_h2s+Hl_h2o


    #Inlet Vapor Enthalpy"""
    Hvch4in=Compounds['ch4'].Hv(300+273.16)*Fvch4in
    Hvco2in=Compounds['co2'].Hv(300+273.16)*Fvco2in 
    Hvh2sin=Compounds['h2s'].Hv(300+273.16)*Fvh2sin
    Hvh2oin=Compounds['h2o'].Hv(300+273.16)*Fvh2oin 
    
    Hvin=Hvch4in+Hvco2in+Hvh2sin+Hvh2oin
    
    #Inlet Liquid Enthalpy"""
    Hlch4in=Compounds['ch4'].Hl(300+273.16)*Flch4in
    Hlco2in=Compounds['co2'].Hl(300+273.16)*Flco2in 
    Hlh2sin=Compounds['h2s'].Hl(300+273.16)*Flh2sin
    Hlh2oin=Compounds['h2o'].Hl(300+273.16)*Flh2oin 

    Hlin=Hlch4in+Hlco2in+Hlh2sin+Hlh2oin
    
    dHvl=Hv-Hl
    dHvl[0]=Hvin-Hl[0]
    
    #Boundary conditions
    dHvl[0]=Hvin-Hl[0]
    dHvl[-1]=Hv[-1]-Hlin
    
    dHavg=np.mean(dHvl)
    errH=dHvl-dHavg
    err=scipy.concatenate((errch4,errco2,errh2s,errh2o,errH))
    return err
    print err
    
    
    
    
        

           
        
        
        
        