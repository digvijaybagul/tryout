# -*- coding: utf-8 -*-
"""
Created on Wed Jan 28 11:40:58 2015

@author: vhd
"""

class DPHex:
    def __init__(self,di,do,L,fann,fpipe):