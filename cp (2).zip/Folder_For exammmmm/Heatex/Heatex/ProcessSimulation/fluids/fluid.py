# -*- coding: utf-8 -*-
"""
Created on Wed Feb 11 10:06:46 2015

@author: vhd
"""

import scipy as sc

from scipy.interpolate import UnivariateSpline as uv
import scipy.integrate as integ
from scipy.integrate import quad
import equipment as equip


class Fluid:
    def __init__(self,fluidproperties):
        self.props=fluidproperties
        self.n=equip.n
        
    def Hlv(self,T,P,Tsat):
        p=self.props
        Psat=p.Psat(T)
        if P<Psat:#gas
            (H1,er)=quad(p.CpG,p.Tf,T)
            H=p.Hf+H1
        else:
            (H1,er)=quad(p.CpG,p.Tf,T)
            H=p.Hf+H1-p.Hv(Tsat)
        return H
    def Hv(self,T):
        p=self.props
        #gas
        (Hv1,er)=quad(p.CpG,p.Tf,T)
        Hv=Hv1+p.Hf
        #Hl=p.Hf+scipy.integrate.quad(p.CpG,p.Tf,T)-p.Hv(T)
        return Hv
    
    def TfromPsat(self,psat,T):
       
        f=uv(psat,T,k=3,s=0)
       
        return f
    def Hl(self,T,Tsat):
        p=self.props
        
        #gas
        (Hl1,er)=quad(p.CpG,p.Tf,T)-p.Hv(Tsat)
        Hl=p.Hf+Hl1
        return Hl 
        
    def TfromHv(self,T,Hv):
        
        f=uv(Hv,T,k=3,s=0)
  
        return f
        
    def TfromHl(self,T,Hl):
       
        f=uv(Hl,T,k=3,s=0)
       
        return f
        
#    def fv(self,H,P):
#        Tsat=self.TfromPsat(P)
#        Hvsat=self.Hv(Tsat)
#        Hlsat=self.Hl(Tsat)
#        if H<Hvsat:
#            fv=0
#            T=self.TfromHl(H)
#        elif H>Hvsat:
#            fv=1
#            T=self.TfromHv(H)
#        else:
#            T=self.TfromPsat(P)
#            fv=(H-Hlsat)/(Hvsat-Hlsat)
#        return T   
        
    def U(self,fva,fvb):
        U=sc.zeros(self.n)
        for i in range(0,self.n):
            
            if fva[i]==0 and fvb[i]==0:
                U[i]=500
            elif (fva[i]>0 and fva[i]<1) and (fvb[i]>0 and fvb[i]<1):
                U[i]=1000
            elif fva[i]==1 and fvb[i]==1:
                U[i]=1000
            elif (fva[i]==1 or fvb[i]==1) and (fva[i]!=fvb[i]):
                U[i]=100
            elif ((fva[i]>0 and fva[i]<1) or (fvb[i]>0 and fvb[i]<1)) and not ((fva[i]>0 and fva[i]<1) and (fvb[i]>0 and fvb[i]<1)):
                U[i]=100
        self.U=U
        return self.U
     def k(self,T,P):
        p=self.fluidproperties
        Psat=p.Psat(T)
        if P<Psat:
            Cp=p.CpG(T)
            mu=p.viscG(T,P)
            Tr=T/(p.Tc)
            k=(1.3+((8.314/(Cp-8.314))*(1.7614-(0.3523/Tr))))*(mu*(Cp-8.314)/p.MW) #linear molecules
#            k=(1.15+((2.033*8.314)/(Cp-8.314)))*(mu*(Cp-8.314)/p.MW) #non lnear molecules
#            k=(2.5*mu*(Cp-8.314))/p.MW #Monoatomic
        else:
            Tr=T/(p.Tc)
            k=((p.A)^(p.alpha))*((p.MW)^-(p.beta))*((p.Tc)^-(p.gamma))*((1-Tr)^0.38)*(Tr^(-1/6))
        return k
        
    def Re(self,T,P,dh,v):
        p=self.fluidproperties
        Psat=p.Psat(T)
        if P<Psat: #gas
            mu=p.viscG(T,P)
            rho=p.MW*P/(8314*T)
        else:
            mu=p.viscL(T,P)
            rho=p.densL(T,P)
        Re=dh*v*rho/mu
        return Re
    def Pr(self,T,P):
        p=self.fluidproperties
        Psat=p.Psat(T)
        if P<Psat:
            Cp=p.CpG(T)
            mu=p.viscG(T,P)
            k=p.k(T)
        else:
            Cp=p.CpL(T)
            mu=p.viscL(T,P)
            k=p.k(T)
        Pr=(Cp*mu)/k
        return Pr
    def Pe(self,Re,Pr):
        Pe=Re*Pr
        return Pe
    def Nu(self,dh,L,Pr,Re,k):
        if Pr<160 and Re<2000 and L/dh<60:
            Nu=0.023*((Re)^0.8)*((Pr)^0.3)
        else:
            0.027*((Re)^(4/5))*((Pr)^(1/3))
        h=(Nu*k)/dh
        return h
    def Sc(self,dh,P,T):
        p=self.fluidproperties
        Psat=p.Psat(T)
        if P<Psat:
            mu=p.viscG(T)
            rho=p.densG(T)
        else:
            mu=p.viscL(T)
            rho=p.densL(T)
        Sc=mu/(rho*dh)
        return Sc
    def Sh(self,Re,Sc):
        Sh=2+(0.552*(Re^0.5)*(Sc*(1/3)))
        return Sh

   
       
        
        