# -*- coding: utf-8 -*-
"""
Created on Sun Feb 15 09:50:27 2015

@author: Girija
"""
import ProcessSimulation.Compounds.water as water
import ProcessSimulation.Compounds.benzene as benzene
import ProcessSimulation.Heatexchanger.equipment as equip
import ProcessSimulation.fluids.fluid as fluid
import scipy as sc
import scipy.optimize as opt
import matplotlib.pyplot as plt

class DPHex:
    def __init__(self,a,b):
        self.ka=equip.ka
        self.kb=equip.kb
        self.Tain=equip.Tain
        self.Tbin=equip.Tbin
        self.n=equip.n
        self.A=equip.A
        self.P=equip.P
        self.L=equip.L
        self.a=a
        self.b=b
        self.set_grid(self.n)
        self.ma=equip.ma
        self.mb=equip.mb
        self.Afa=equip.Afa
        self.Afb=equip.Afb
       
        
    def set_grid(self,n):
        self.n=self.n
        a=self.a
        b=self.b
        
        self.dA=self.A/(n-1)
        self.dx=self.L/(n-1)
        '''chart'''
        self.Tcharta=sc.linspace(self.Tbin,self.Tain,self.n)
        self.Tchartb=sc.linspace(self.Tbin,self.Tain,self.n)
        self.psatcharta=a.props.Psat(self.Tcharta)
        self.psatchartb=b.props.Psat(self.Tchartb)
        self.TfromPsat=a.TfromPsat(self.psatcharta,self.Tcharta)
        self.TfromPsatb=b.TfromPsat(self.psatchartb,self.Tchartb)
        Tsat1=a.TfromPsat(self.psatcharta,self.Tcharta)
        self.Tsata=Tsat1(self.P)
        Tsat2=b.TfromPsat(self.psatchartb,self.Tchartb)
        self.Tsatb=Tsat2(self.P)
        self.Hvcharta=[]
        self.Hvchartb=[]
        self.Hlcharta=[]
        self.Hlchartb=[]
        for i in self.Tcharta:
            Hv=a.Hv(i)
            self.Hvcharta += [Hv]
            Hl=a.Hl(i,self.Tsata)
            self.Hlcharta += [Hl]
        for i in self.Tchartb:
            Hv=b.Hv(i)
            self.Hvchartb += [Hv]
            Hl=b.Hl(i,self.Tsatb)
            self.Hlchartb += [Hl]
        '''spline'''
        
        self.TfromHv=a.TfromHv(self.Tcharta,self.Hvcharta)
        self.TfromHl=a.TfromHl(self.Tcharta,self.Hlcharta)
        
        self.TfromHvb=b.TfromHv(self.Tchartb,self.Hvchartb)
        self.TfromHlb=b.TfromHl(self.Tchartb,self.Hlchartb)
        '''guess'''
        self.Ha=a.Hlv(self.Tain,self.P,self.Tsata)
        self.Hb=b.Hlv(self.Tbin,self.P,self.Tsatb)
        self.Haguess=sc.ones(n)*self.Ha
        self.Hbguess=sc.ones(n)*self.Hb
        self.Hguess=sc.concatenate((self.Haguess,self.Hbguess))
        
        self.Hvsata=a.Hv(self.Tsata)
        self.Hvsatb=b.Hv(self.Tsatb)
        self.Hlsata=a.Hl(self.Tsata,self.Tsata)
        self.Hlsatb=b.Hl(self.Tsatb,self.Tsatb)
        
    def itra(self,H):
        n=self.n
        T=sc.zeros(n)
        fv=sc.zeros(n)
        Hvsat=self.Hvsata
        Hlsat=self.Hlsata
       
        for i in range(0,n):
            if H[i]<Hlsat:
                fv[i]=0
                T[i]=self.TfromHl(H[i])
               
                
            elif H[i]>Hvsat:
                fv[i]=1
                T[i]=self.TfromHv(H[i])
               
               
            else:
                T[i]=self.Tsata
                fv[i]=(H[i]-self.Hlsata)/(self.Hvsata-self.Hlsata)
        
        return T,fv
    def itrb(self,H):
        n=self.n
        T=sc.zeros(n)
        fv=sc.zeros(n)
        Hvsat=self.Hvsatb
        Hlsat=self.Hlsatb
 
        for i in range(0,n):
            if H[i]<Hlsat:
                fv[i]=0
                T[i]=self.TfromHlb(H[i])
               
                
            elif H[i]>Hvsat:
                fv[i]=1
                T[i]=self.TfromHvb(H[i])
               
               
            else:
                T[i]=self.Tsatb
                fv[i]=(H[i]-self.Hlsatb)/(self.Hvsatb-self.Hlsatb)
         
        return T,fv
        
        
    def solve(self):
        
        Hguess=self.Hguess
        Hsoln=opt.leastsq(residuals,Hguess,args=(self))[0]
        self.Hasoln=Hsoln[:self.n]
        self.Hbsoln=Hsoln[self.n:]
        self.Hasoln[0]=self.Ha
        self.Hbsoln[-1]=self.Hb
        self.Tasoln=self.itra(self.Hasoln)      
        self.Tbsoln=self.itrb(self.Hbsoln)
        
         
  
    

   

def residuals(H,obj):
    
    n=obj.n
    P=obj.P
    
    Hag=H[:n]
    Hbg=H[n:]
    fa=obj.itra(Hag)
    fb=obj.itrb(Hbg)
    Ta=fa[0]
    fva=fa[1]
    Tb=fb[0]
    fvb=fb[1]
    U1=fluid.Fluid(water)
    U=U1.U(fva,fvb)
    Tain=obj.Tain
    Tbin=obj.Tbin
    Ha=obj.Ha
    Hb=obj.Hb
    ma=obj.ma
    mb=obj.mb
    Ha1=H[:n]
    Hb1=H[n:]
    Ha1[0]=Ha
    Hb1[-1]=Hb
    dx=obj.dx
    dA=obj.dA
    Afa=obj.Afa
    Afb=obj.Afb
    ka=obj.ka
    kb=obj.kb
    Ta[0]=Tain
    Tb[-1]=Tbin
#    #for left  a-1-in b-1-0
#    errHal=(ka*Afa*((((obj.itra(Ha1[2])-obj.itra(Ha1[1]))/dx)-((obj.itra(Ha1[1])-obj.itra(Ha))/dx))/dx))-(ma*(Ha1[1]-Ha)/dx)-(U*(Tain-obj.itra(Hb1[0]))*dA/dx)
#    errHbl=(kb*Afb*((((obj.itrb(Hb1[2])-obj.itrb(Hb1[1]))/dx)-((obj.itrb(Hb1[1])-obj.itrb(Hb1[0]))/dx))/dx))-(mb*(Hb1[1]-Hb1[0])/dx)-(U*(Tain-obj.itrb(Hb1[0]))*dA/dx)
#    #for right
#    errHar=(ka*Afa*((((obj.itra(Ha1[-1])-obj.itra(Ha1[-2]))/dx)-((obj.itra(Ha1[-2])-obj.itra(Ha1[-3]))/dx))/dx))-(ma*(Ha1[-1]-Ha1[-2])/dx)-(U*(obj.itra(Ha1[-1])-Tbin)*dA/dx)
#    errHbr=(kb*Afb*((((obj.itrb(Hb)-obj.itrb(Hb1[-2]))/dx)-((obj.itrb(Hb1[-2])-obj.itrb(Hb1[-3]))/dx))/dx))-(mb*(Hb-Hb1[-2])/dx)-(U*(obj.itra(Ha1[-1],P)-Tbin)*dA/dx)
#    errHa=sc.zeros(n)
#    errHb=sc.zeros(n)
#    errHa[0]=errHal
#    errHa[-1]=errHar
#    errHb[0]=errHbl
#    errHb[-1]=errHbr
#    #
#    
#    
#    errHa[1:-1]=(ka*Afa*((((obj.itra(Ha1[3:])-obj.itra(Ha1[2:-1]))/dx)-((obj.itra(Ha1[2:])-obj.itra(Ha1[1:-1]))/dx))/dx))-(ma*(Ha1[2:]-Ha1[1:-1])/dx)-(U*(obj.itra(Ha1[1:-1])-obj.itrb(Hb1[1:-1]))*dA/dx)
#    errHb[1:-1]=(kb*Afb*((((obj.itrb(Hb1[3:])-obj.itrb(Hb1[2:-1]))/dx)-((obj.itrb(Hb1[2:])-obj.itrb(Hb1[1:-1]))/dx))/dx))-(mb*(Hb1[2:]-Hb1[1:-1])/dx)-(U*(obj.itra(Ha1[1:-1],P)-obj.itrb(Hb1[1:-1]))*dA/dx)
    
    #for left  a-1-in b-1-0
    errHal=(ka*Afa*(((Ta[2]-Ta[1])/dx)-((Ta[1]-Tain)/dx))/dx)-(ma*(Ha1[1]-Ha)/dx)-(U[0]*(Tain-Tb[0])*dA/dx)
    errHbl=(kb*Afb*(((Tb[2]-Tb[1])/dx)-((Tb[1]-Tb[0])/dx))/dx)-(mb*(Hb1[1]-Hb1[0])/dx)-(U[0]*(Tain-Tb[0])*dA/dx)
    #for right
    errHar=(ka*Afa*((((Ta[-1]-Ta[-2])/dx)-((Ta[-2]-Ta[-3])/dx))/dx))-(ma*(Ha1[-1]-Ha1[-2])/dx)-(U[-1]*(Ta[-1]-Tbin)*dA/dx)
    errHbr=(kb*Afb*((((Tbin-Tb[-2])/dx)-((Tb[-2]-Tb[-3])/dx))/dx))-(mb*(Hb-Hb1[-2])/dx)-(U[-1]*(Ta[-1]-Tbin)*dA/dx)
    errHa=sc.zeros(n)
    errHb=sc.zeros(n)
    errHa[0]=errHal
    errHa[-1]=errHar
    errHb[0]=errHbl
    errHb[-1]=errHbr
    #
    
    
    errHa[1:-1]=(ka*Afa*((((Ta[2:]-Ta[1:-1])/dx)-((Ta[1:-1]-Ta[0:-2])/dx))/dx))-(ma*(Ha1[2:]-Ha1[1:-1])/dx)-(U[1:-1]*(Ta[1:-1]-Tb[1:-1])*dA/dx)
    errHb[1:-1]=(kb*Afb*((((Tb[2:]-Tb[1:-1])/dx)-((Tb[1:-1]-Tb[0:-2])/dx))/dx))-(mb*(Hb1[2:]-Hb1[1:-1])/dx)-(U[1:-1]*(Ta[1:-1]-Tb[1:-1])*dA/dx)
    
    
    
    return sc.concatenate((errHa,errHb))
  
a=fluid.Fluid(water)
b=fluid.Fluid(benzene)    
DP=DPHex(a,b)

x=DP.solve()

a=range(0,100,10)
plt.plot(a,DP.Tasoln[0],'r')
plt.show()
a=range(0,100,10)
plt.plot(a,DP.Tbsoln[0],'b')
plt.show()


