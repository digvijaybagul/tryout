# -*- coding: utf-8 -*-
"""
Created on Thu Mar 12 00:17:38 2015

@author: Girija
"""
import scipy as sc
import scipy.optimize as opt
import numpy as np
import os
import win32com.client as win
thisdir=os.getcwd()+'/'
filename='NRTL-final.xlsx'
xl=win.gencache.EnsureDispatch("Excel.Application")
xl.Visible=True
wb=xl.Workbooks.Open(thisdir+filename)
Sheet=wb.Sheets("Sheet2")

""" 2-Toluene
    1-CHA"""
    
F=Sheet.Range("B4").Value
xF=Sheet.Range("B5").Value
D=Sheet.Range("B6").Value
xD=Sheet.Range("B7").Value
q=Sheet.Range("B10").Value
B=Sheet.Range("B11").Value
xB=Sheet.Range("B12").Value
xe=np.arange(10,dtype=float)
for i in range(10):
    xe[i]=Sheet.Cells(i+4,5).Value
    i=i+1
ye=np.arange(10,dtype=float)
for i in range(10):
    ye[i]=Sheet.Cells(i+4,6).Value
    i=i+1
    

def residuals(T,x):
    P=Sheet.Range("C26").Value
    x2=x
    x1=1-x2
    '''VP'''
    A1=Sheet.Range("N20").Value
    B1=Sheet.Range("O20").Value
    C1=Sheet.Range("P20").Value
    VP1=10**5*(10**(A1-(B1/(T+C1))))
    A2=Sheet.Range("H20").Value
    B2=Sheet.Range("I20").Value
    C2=Sheet.Range("J20").Value
    VP2=1000*(sc.exp(A2-(B2/((T-273.16)+C2))))
    """NRTL const"""
    a12=Sheet.Range("B28").Value
    dg1=Sheet.Range("D28").Value
    dg2=Sheet.Range("F28").Value
    T12=dg1/(8.314*T)
    T21=dg2/(8.314*T)
    G12=sc.exp(-a12*T12)
    G21=sc.exp(-a12*T21)
    """gamma"""
    g1=sc.exp(x2**2*((T21*(G21/(x1+(x2*G21)))**2)+(G12*T12/(x2+(x1*G12))**2)))
    g2=sc.exp(x1**2*((T12*(G12/(x2+(x1*G12)))**2)+(G21*T21/(x1+(x2*G21))**2)))
    """error"""
    err=P-x1*g1*VP1-x2*g2*VP2
    
    return err
    
def y(T,x):
    P=Sheet.Range("C26").Value
    x2=x
    x1=1-x2
    '''VP'''
    A1=Sheet.Range("N20").Value
    B1=Sheet.Range("O20").Value
    C1=Sheet.Range("P20").Value
    VP1=10**5*(10**(A1-(B1/(T+C1))))
    A2=Sheet.Range("H20").Value
    B2=Sheet.Range("I20").Value
    C2=Sheet.Range("J20").Value
    VP2=1000*(sc.exp(A2-(B2/((T-273.16)+C2))))
    """NRTL const"""
    a12=Sheet.Range("B28").Value
    dg1=Sheet.Range("D28").Value
    dg2=Sheet.Range("F28").Value
    T12=dg1/(8.314*T)
    T21=dg2/(8.314*T)
    G12=sc.exp(-a12*T12)
    G21=sc.exp(-a12*T21)
    """gamma"""
    g1=sc.exp(x2**2*((T21*(G21/(x1+(x2*G21)))**2)+(G12*T12/(x2+(x1*G12))**2)))
    g2=sc.exp(x1**2*((T12*(G12/(x2+(x1*G12)))**2)+(G21*T21/(x1+(x2*G21))**2)))
    y2=x2*g2*VP2/P
    
    return y2
    
"""Rmin"""   
tguess=383
x=xF   
T1=opt.leastsq(residuals,tguess,args=(x))
ymin=y(T1[0],xF)
Rmin=(xD-ymin)/(ymin-xF)
R=1.5*Rmin
L=R*D
V=L+D
L1=L+(q*F)
V1=V-(1-q)*F


"""stages-stripping"""
n1=0
x1=xB
tguess=383
while (x1 <= xF):
    T1=opt.leastsq(residuals,tguess,args=(x1))
    y1=y(T1[0],x1)
    x2=((L1-B)*y1/L1)+(B*xB/L1)
    x1=x2
    n1=n1+1
    
print n1

"""stages-rectification"""
n2=0
while(x1<=xD):
    T1=opt.leastsq(residuals,tguess,args=(x1))
    y1=y(T1[0],x1)
    x2=((L+D)*y1/L)-(D*xD/L)
    x1=x2
    n2=n2+1
    
print n2
    
print n1+n2


    



   
    

    



