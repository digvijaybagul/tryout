# -*- coding: utf-8 -*-
"""
Created on Thu Mar 12 00:48:35 2015

@author: Girija
"""
def f(a):
    a=2*a
    return a
    
b=f(4)
print b
x=5
while (x>=3):
    print x
    x=x-1
