# -*- coding: utf-8 -*-
"""
Created on Wed Feb 11 10:06:46 2015

@author: vhd
"""

import scipy as sc

from scipy.interpolate import UnivariateSpline as uv
import scipy.integrate as integ
from scipy.integrate import quad



class Fluid:
    def __init__(self,fluidproperties):
        self.props=fluidproperties
        
        
    def Hlv(self,T,P,Tsat):
        p=self.props
        Psat=p.Psat(T)
        if P<Psat:#gas
            (H1,er)=quad(p.CpG,p.Tf,T)
            H=p.Hf+H1
        else:
            (H1,er)=quad(p.CpG,p.Tf,T)
            H=p.Hf+H1-p.Hv(Tsat)
        return H
    def Hv(self,T):
        p=self.props
        #gas
        (Hv1,er)=quad(p.CpG,p.Tf,T)
        Hv=Hv1+p.Hf
        #Hl=p.Hf+scipy.integrate.quad(p.CpG,p.Tf,T)-p.Hv(T)
        return Hv
    
    def TfromPsat(self,psat,T):
       
        f=uv(psat,T,k=3,s=0)
       
        return f
    def Hl1(self,T,Tsat): # heat of vapourization
        p=self.props
        Hl1=quad(p.CpG,p.Tf,T)[0]-p.Hv(Tsat)
        Hl=p.Hf+Hl1
        return Hl
        
    def Hl2(self,T): # heat of solution
        p=self.props
        Hl2=quad(p.CpG,p.Tf,T)[0]-p.Habs
        Hl=p.Hf+Hl2
        return Hl
        
    
        
    def TfromHv(self,T,Hv):
        
        f=uv(Hv,T,k=3,s=0)
  
        return f
        
    def TfromHl(self,T,Hl):
       
        f=uv(Hl,T,k=3,s=0)
       
        return f
        
    def kga(self,T):
        kga=0.001
        return kga
        
    def kla(self,T):
        kla=0.0001
        return kla
   
       
        
        