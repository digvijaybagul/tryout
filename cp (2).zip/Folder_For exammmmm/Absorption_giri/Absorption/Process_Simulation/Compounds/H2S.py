# -*- coding: utf-8 -*-
"""
Created on Wed Mar 11 13:49:52 2015

@author: vhd
"""

import scipy as sc
import numpy as np


#H2S
MW=34.081 #K
Tc=373.53 #K
Pc=8.963e6 #pa
Zc=0.284
acc=0.0942
Hf=-2.063e7 #J/kmol
Tf=298.15 #K
Pf=101325 #Pa  

def CpG(T): #J/(kmol K)
    C1=0.33288*10**5;C2=0.26086*10**5;C3=0.9134*10**3;C4=-0.17979*10**5;C5=949.4
    cpg=C1+C2*(((C3/T)/(np.sinh(C3/T)))**2)+C4*((C5/T)/(np.cosh(C5/T)))**2
    return cpg
    
def Hv(T):
    Tc=647.096
    Tr=T/Tc  # hv=J/kmol T,Tc =K
    C1=2.5676*10**7;C2=0.37358;C3=0;C4=0;C5=0
    Hv=C1*(1-Tr)**(C2+(C3*Tr)+(C4*Tr**2)+(C5*Tr**3))
    return Hv
    
def kH(T):
    kHo=1e-3
    dH=2300 #dh/R
    kH=kHo*sc.exp(-dH*((1/T)-(1/298)))/101325 #kmol/m3Pa
    return 1/kH
    
Habs=2300*8314 #j/kmol