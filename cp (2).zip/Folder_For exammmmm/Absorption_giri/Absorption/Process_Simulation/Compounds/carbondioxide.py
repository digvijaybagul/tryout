# -*- coding: utf-8 -*-
"""
Created on Wed Mar 11 13:45:20 2015

@author: vhd
"""
import scipy as sc
import numpy as np
MW=44.01 #K
Tc=304.21 #K
Pc=7.383e6 #pa
Zc=0.274
acc=0.2236
Hf=-39.351e7 #J/kmol
Tf=298.15 #K
Pf=101325 #Pa  

def CpG(T): #J/(kmol K)
    C1=0.2937*10**5;C2=0.3454*10**5;C3=1.428*10**3;C4=0.264*10**5;C5=588
    cpg=C1+C2*(((C3/T)/(np.sinh(C3/T)))**2)+C4*((C5/T)/(np.cosh(C5/T)))**2
    return cpg 
    
        
def Hv(T):
    Tc=304.21
    Tr=T/Tc  # hv=J/kmol T,Tc =K
    C1=2.173*10**7;C2=0.382;C3=-0.4339;C4=0.42213;C5=0 #water
    Hv=C1*(1-Tr)**(C2+(C3*Tr)+(C4*Tr**2)+(C5*Tr**3))
    return Hv
    


def kH(T):
    kHo=9.5e-4
    dH=1300 #dh/R
    kH=kHo*sc.exp(-dH*((1/T)-(1/298)))/101325 #mol/m3Pa
    return 1/kH
    
Habs=1300*8314 #J/kmol
    