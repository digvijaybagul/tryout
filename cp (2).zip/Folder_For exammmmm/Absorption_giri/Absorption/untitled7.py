# -*- coding: utf-8 -*-
"""
Created on Wed Mar 11 16:01:44 2015

@author: vhd
"""
import numpy as np

class tp:
    def __init__(self,a,b):
        self.a=a
        self.b=b
    def g(self):
        e=self.d(1,3)*2
        return e
    def d(self,a,b):
        c=a+b
        return c
        
h=tp(1,2)   
     
k=h.g()
print k

import scipy as sc
err=sc.zeros(10)
print err

a=[0.9999,0.0006,0.9999]
b=[0.00001,0.000001,0.000001]

c=a[0]/b[0]
print c
ErrFva=sc.ones(20)
print ErrFva
n=20



Fva=sc.linspace(1,10,10)
print Fva
print np.gradient(Fva)

Tin=30
Tout=30
n=20
Tcharta=sc.linspace(Tin,Tout,n)
print Tcharta

#    """first point and last point"""
#    Ra_num=sc.ones(n)
#    Ra_den=sc.ones(n)
#    ErrFva=sc.ones(n)
#    ErrFla=sc.ones(n)
#    Ra_num[0]=(((P*Fva[0]/(Fva[0]+Fvb[0]+Fvc[0]+Fvd[0]))/(a.props.kH(T[0])))-(Fla[0]*a.props.rho/(Fla[0]+Flb[0]+Flc[0]+Fld[0])))
#    Ra_den[0]=(1/((a.props.kH(T[0])*a.kga)))+(1/a.kla)
#    ErrFva[0]=((Fva[1]-Fva[0])/dx)+(S*(Ra_num[0])/(Ra_den[0]))
#    ErrFla[0]=((Fla[1]-Fla[0])/dx)+(S*(Ra_num[0])/Ra_den[0])
#    Ra_num[-1]=(((P*Fva[-1]/(Fva[-1]+Fvb[-1]+Fvc[-1]+Fvd[-1]))/(a.props.kH(T[-1])))-(Fla[-1]*a.props.rho/(Fla[-1]+Flb[-1]+Flc[-1]+Fld[-1])))
#    Ra_den[-1]=(1/((a.props.kH(T[-1])*a.kga)))+(1/a.kla)
#    ErrFva[-1]=((Fva[-1]-Fva[-2])/dx)+(S*(Ra_num[-1])/(Ra_den[-1]))
#    ErrFla[-1]=((Fla[-1]-Fla[-2])/dx)+(S*(Ra_num[-1])/Ra_den[-1])
#        
#    Rb_num=sc.zeros(n)
#    Rb_den=sc.zeros(n)
#    Rb_num[0]=(((P*Fvb[0]/(Fva[0]+Fvb[0]+Fvc[0]+Fvd[0]))/(b.props.kH(T[0])))-(Flb[0]*b.props.rho/(Fla[0]+Flb[0]+Flc[0]+Fld[0])))
#    Rb_den[0]=(1/((b.props.kH(T[0])*b.kga)))+(1/b.kla)
#    ErrFvb=sc.zeros(n)
#    ErrFlb=sc.zeros(n)
#    ErrFvb[0]=((Fvb[1]-Fvb[0])/dx)+(S*Rb_num[0]/Rb_den[0])
#    ErrFlb[0]=((Flb[1]-Flb[0])/dx)+(S*Rb_num[0]/Rb_den[0])
#    Rb_num[-1]=(((P*Fvb[-1]/(Fva[-1]+Fvb[-1]+Fvc[-1]+Fvd[-1]))/(b.props.kH(T[-1])))-(Flb[-1]*b.props.rho/(Fla[-1]+Flb[-1]+Flc[-1]+Fld[-1])))
#    Rb_den[-1]=(1/((b.props.kH(T[-1])*b.kga)))+(1/b.kla)
#    ErrFvb[-1]=((Fvb[-1]-Fvb[-2])/dx)+(S*Rb_num[-1]/Rb_den[-1])
#    ErrFlb[-1]=((Flb[-1]-Flb[-2])/dx)+(S*Rb_num[-1]/Rb_den[-1])
#    
#    Rc_num=sc.zeros(n)
#    Rc_den=sc.zeros(n)
#    Rc_num[0]=(((P*Fvc[0]/(Fva[0]+Fvb[0]+Fvc[0]+Fvd[0]))/(c.props.kH(T[0])))-(Flc[0]*c.props.rho/(Fla[0]+Flb[0]+Flc[0]+Fld[0])))
#    Rc_den[0]=(1/((c.props.kH(T[0])*c.kga)))+(1/c.kla)
#    ErrFvc=sc.zeros(n)
#    ErrFlc=sc.zeros(n)
#    ErrFvc[0]=((Fvc[1]-Fvc[0])/dx)+(S*Rc_num[0]/Rc_den[0])
#    ErrFlc[0]=((Flc[1]-Flc[0])/dx)+(S*Rc_num[0]/Rc_den[0])
#    Rc_num[-1]=(((P*Fvc[-1]/(Fva[-1]+Fvb[-1]+Fvc[-1]+Fvd[-1]))/(c.props.kH(T[-1])))-(Flc[-1]*c.props.rho/(Fla[-1]+Flb[-1]+Flc[-1]+Fld[-1])))
#    Rc_den[-1]=(1/((c.props.kH(T[-1])*c.kga)))+(1/c.kla)
#    ErrFvc[-1]=((Fvc[-1]-Fvc[-2])/dx)+(S*Rc_num[-1]/Rc_den[-1])
#    ErrFlc[-1]=((Flc[-1]-Flc[-2])/dx)+(S*Rc_num[-1]/Rc_den[-1])
#    
#    hv=sc.zeros(n)
#    hl=sc.zeros(n)
#    errH=sc.zeros(n)
#    hv[0]=Fva[0]*a.Hv(T)+Fvb[0]*b.Hv(T)+Fvc[0]*c.Hv(T)+Fvd[0]*d.Hv(T)
#    hl[0]=Fla[0]*a.Hl2(T)+Flb[0]*b.Hl2(T)+Flc[0]*c.Hl2(T)+Fld[0]*d.Hl1(T,d.props.Tsat)
#    hv[1]=Fva[1]*a.Hv(T)+Fvb[1]*b.Hv(T)+Fvc[1]*c.Hv(T)+Fvd[1]*d.Hv(T)
#    hl[1]=Fla[1]*a.Hl2(T)+Flb[1]*b.Hl2(T)+Flc[1]*c.Hl2(T)+Fld[1]*d.Hl1(T,d.props.Tsat)
#    errH[0]=((hv[1]-hv[0])/dx)-((hl[1]-hl[0])/dx)
#    hv[-1]=obj.Htot(Fva[-1],Fvb[-1],Fvc[-1],Fvd[-1],Fla[-1],Flb[-1],Flc[-1],Fld[-1],T[-1])[0]
#    hl[-1]=obj.Htot(Fva[-1],Fvb[-1],Fvc[-1],Fvd[-1],Fla[-1],Flb[-1],Flc[-1],Fld[-1],T[-1])[1]
#    hv[-2]=obj.Htot(Fva[-2],Fvb[-2],Fvc[-2],Fvd[-2],Fla[-2],Flb[-2],Flc[-2],Fld[-2],T[-2])[0]
#    hl[-2]=obj.Htot(Fva[-2],Fvb[-2],Fvc[-2],Fvd[-2],Fla[-2],Flb[-2],Flc[-2],Fld[-2],T[-2])[1]
#    errH[-1]=((hv[-1]-hv[-2])/dx)-((hl[-1]-hl[-2])/dx)
#    
#    """middle"""



#    Hv=guess[0:n]
#    Hl=guess[n:2*n]
#    Fva=guess[2*n:3*n]
#    Fvb=guess[3*n:4*n]
#    Fvc=guess[4*n:5*n]
#    Fvd=guess[5*n:6*n]
#    Fla=guess[6*n:7*n]
#    Flb=guess[7*n:8*n]
#    Flc=guess[8*n:9*n]
#    Fld=guess[9*n:10*n]

import Process_Simulation.input.input as ip
import scipy as sc
import Process_Simulation 
import Process_Simulation.Compounds.water as water
import Process_Simulation.Compounds.methane as CH4
import Process_Simulation.Compounds.carbondioxide as CO2
import Process_Simulation.Compounds.H2S as H2S
import Process_Simulation.fluid.fluid as fluid
import numpy as np
import scipy.optimize as opt

#a=fluid.Fluid(CH4)
#b=fluid.Fluid(CO2)
#c=fluid.Fluid(H2S)
#d=fluid.Fluid(water)
#D=0.9
#S=(sc.pi*D**2)/4
#
#Ra_num=sc.ones(10)
#Ra_den=sc.ones(10)
#ErrFva=sc.ones(10)
#ErrFla=sc.ones(10)
#T=[303.15]*10
#Fva=[50]*10
#Fvb=[45]*10
#Fvc=[5]*10
#Fvd=[0]*10
#Fla=[0]*10
#Flb=[0]*10
#Flc=[0]*10
#Fld=[1000]*10
#
#
#Ra_num=(((101325*Fva/(Fva+Fvb+Fvc+Fvd))/(a.props.kH(T)))-(Fla*55/(Fla+Flb+Flc+Fld)))
#Ra_den=(1/((a.props.kH(T)*a.kga())))+(1/a.kla())
#ErrFva=(np.gradient(Fva)/0.3)+(S*(Ra_num)/(Ra_den))
#ErrFla=(np.gradient(Fla)/0.3)+(S*(Ra_num)/Ra_den)
#
#print Ra_num,Ra_den

n=20
#for i in range(1,n):
#    print i
#
#        ErrFva=(np.gradient(Fva)/dx)+(S*(Ra_num)/(Ra_den))
#        ErrFla=(np.gradient(Fla)/dx)+(S*(Ra_num)/Ra_den)
#        
#        ErrFvb=(np.gradient(Fvb)/dx)+(S*Rb_num/Rb_den)
#        ErrFlb=(np.gradient(Flb)/dx)+(S*Rb_num/Rb_den)
#        
#        ErrFvc=(np.gradient(Fvc)/dx)+(S*Rc_num/Rc_den)
#        ErrFlc=(np.gradient(Flc)/dx)+(S*Rc_num/Rc_den)
#        
#        ErrFvd=(np.gradient(Fvd)/dx)+(S*Rd_num/Rd_den)
#        ErrFld=(np.gradient(Fld)/dx)+(S*Rd_num/Rd_den)
