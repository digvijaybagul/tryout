# -*- coding: utf-8 -*-
"""
Created on Wed Aug 12 09:31:09 2015

@author: KasturiSarang
"""

 # -*- coding: utf-8 -*-
"""
Created on Tue Jan 20 17:07:29 2015

@author: Vishwanath H. Dalvi
"""

'''
Perry's Handbook VII:    
Vapour Pressure Table 2-6
Densities of pure substance Table 2-30
Critical Constants and Acentric Factors of Inorganic and Organic Compounds Table 2-164    
Heats of Vapourization:  Table 2-193 
Heat Capacities in Ideal Gas State Table 2-198
Heats and Free Energies of Formation and Combustion Table 2-221
'''

import os
import pandas
import scipy as sc
import selenium
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import selenium.webdriver.firefox
import time
import win32com.client
import scipy.interpolate as interp
import scipy.integrate as integ
from scipy.optimize import fsolve

filename = 'PerryData.xlsx'
thisdir = os.getcwd()    #get current wrkin directory
if os.path.isdir("PerryData"):
    os.chdir("PerryData")
xl_file = pandas.ExcelFile(filename)
os.chdir(thisdir)
df = {}  #dataframe or dict of dataframe
df["Critical"] = xl_file.parse("Critical") #df is dict, critical is the sheet we want
#parse will read the sheet and returns the data in sheet to the dataframe
df["LiqDens"] = xl_file.parse("LiqDens")
df["Pvap"] = xl_file.parse("Pvap")
df["Hvap"] = xl_file.parse("Hvap")
df["CpIG"] = xl_file.parse("CpIG")
df["HandGf"] = xl_file.parse("HandGf")

#first line of excel sheet should have headlines only dont mergerows first
#name1 = input('compoundname:')
#class excel:
#    def __init__(self,name1):
#       if name1 == 'Nitrogen':
#           
#           filename_1 = "n2.xlsx"
#       elif name1 == 'Carbon dioxide':
#           
#           filename_1 = "n2.xlsx"
#       elif name1 == 'Methane':
#           filename_1 = "CH4.xlsx"
#       
#       elif name1 == 'Oxygen':
#           filename_1 = "n2.xlsx"  
#       
#       elif name1 == 'Air' :
#           filename_1 = "air.xlsx"
#       self.getexcel()
    
       

         
    
filename_1 = "CH4.xlsx"
xl = win32com.client.gencache.EnsureDispatch("Excel.Application") #excel has been started
wb = xl.Workbooks.Open(thisdir +"/"+ filename_1)
xl.Visible = True 
ws1 = wb.Sheets("Sheet1")

n = 10
#P = sc.linspace(1,20,n)
#T = sc.linspace(25,340,n)


class Compound:
    def __init__(self, name):
        self.Name = name
        self.z = 0
#        self.name1=excel('name')        
        self.getCriticalConstants()
        self.getHandGofFormation()
        self.constCp = self.getConstants('CpIG')
        self.constPvap = self.getConstants('Pvap')
        self.constHvap = self.getConstants('Hvap')
        self.constLiqDens = self.getConstants('LiqDens')
        #n=self.z
        for j in range(0,n):
            for i in range(0,n):
                self.z = self.z + 1
        self.getdata()
    def getCriticalConstants(self):
        name = self.Name
        db = df['Critical']
        comp = db[db.Name == name] #truncated database
        self.MW = comp.MolWt.values[0]  #write MolWt exactly as it is in the excel sheet
        self.Tc = comp.Tc.values[0]
        self.Pc = comp.Pc.values[0]
        self.Vc = comp.Vc.values[0]
        self.Zc = comp.Zc.values[0]
        self.acc = comp.Acc.values[0]
    def getdata(self):
        n = self.z
        self.specenth = sc.zeros(n)
        self.specent = sc.zeros(n)
        self.prandtl = sc.zeros(n)
        self.Ps = sc.zeros(n)
        self.Ts = sc.zeros(n)
        self.Cp = sc.zeros(n)
        self.Cv = sc.zeros(n)
        self.rho = sc.zeros(n)
        
        for j in range(0,n):
            self.specenth[j] = ws1.Cells(3+j,4).Value
            self.specent[j] = ws1.Cells(3+j,5).Value
            self.prandtl[j] = ws1.Cells(3+j,7).Value
            self.Ps[j] = ws1.Cells(3+j,3).Value
            self.Ts[j] = ws1.Cells(3+j,2).Value
            self.Cp[j] = ws1.Cells(3+j,8).Value
            self.Cv[j] = ws1.Cells(3+j,9).Value
            self.rho[j] = ws1.Cells(3+j,6).Value    
    
    
    def getHandGofFormation(self):
        name = self.Name
        db = df['HandGf']
        comp = db[db.Name == name]
        self.Hf = comp.Hf.values[0]
        self.Gf = comp.Gf.values[0]
        self.Tf = 298.15 #K
        self.Pf = 1.0e5 #Pa
        self.Sf = (self.Hf - self.Gf)/self.Tf
        self.Sfabinit = comp.Sf.values[0]
        self.Hcomb = comp.Hcomb.values[0]
    def getConstants(self, sheet):
        name = self.Name
        cnsts = ['C1','C2','C3','C4','C5']
        constants = []
        db = df[sheet] #you need to ask constants for what?
        comp = db[db.Name == name]
        for cnst in cnsts:
            try: #try and except are for error handling, they prevent ur program from crashing
                constants.append(comp[cnst].values[0])
            except KeyError:
                pass
        return constants        
    def CpIG(self, T):
        [C1, C2, C3, C4, C5] = self.constCp
        cp  = C1 
        cp += C2*((C3/T)/sc.sinh(C3/T))**2
        cp += C4*((C5/T)/sc.cosh(C5/T))**2
        return cp/self.MW/1000
        
    
    def H_PT(self,P,T):
        prop_eqn = interp.bisplrep(self.Ps,self.Ts,self.specenth)
                
        if T>0 and T<151:        
            Hnew = interp.bisplev(P,T,prop_eqn)*self.MW/1000
            
            
        elif T>=151:
            Hnew = ((self.Hf/self.MW/1000 + integ.quad(self.CpIG,(self.Tf),(T+273))[0]))
            
        return Hnew 
        
    def S_PT(self,P,T):
        prop_eqn = interp.bisplrep(self.Ps,self.Ts,self.specent)        
        global S_new
        if T>0 and T<150:
            S_new = interp.bisplev(P,T,prop_eqn)*self.MW/1000
        elif T>=151:
            S_new = ((self.Sf/self.MW/1000 + integ.quad(self.CpIG/T,(self.Tf),(T+273.16))[0]))
        return S_new   
        
    def Pr_PT(self,P,T):
        prop_eqn = interp.bisplrep(self.Ps,self.Ts,self.prandtl)
        Pr_new = interp.bisplev(P,T,prop_eqn)
        return Pr_new
        
    def Cp_PT(self,P,T):
        prop_eqn = interp.bisplrep(self.Ps,self.Ts,self.Cp)
        
        if T>0 and T<166: 
            Cp_new = interp.bisplev(P,T,prop_eqn)*self.MW/1000
        elif T>166: 
            Cp_new = integ.quad(self.CpIG,self.Tf,T)
        return Cp_new
        
    def H_PS(self,P,S):
        prop_eqn = interp.bisplrep(self.Ps,self.specent,self.specenth)
        Hps = interp.bisplev(P,S,prop_eqn)*self.MW/1000
        return Hps 
    
        
    def Cp_PS(self,P,S):
        prop_eqn = interp.bisplrep(self.Ps,self.specent,self.Cp)
        rho_new = interp.bisplev(P,S,prop_eqn)*self.MW/1000
        return rho_new
    
    def Cv_PS(self,P,S):
        prop_eqn = interp.bisplrep(self.Ps,self.specent,self.Cv)
        rho_new = interp.bisplev(P,S,prop_eqn)*self.MW/1000
        return rho_new
        
    def rho_PS(self,P,S):
        prop_eqn = interp.bisplrep(self.Ps,self.specent,self.rho)
        rho_new = interp.bisplev(P,S,prop_eqn)
        return rho_new
        
    def S_PH(self,P,H):
        prop_eqn = interp.bisplrep(self.Ps,self.specenth,self.specent)
        rho_new = interp.bisplev(P,H,prop_eqn)*self.MW/1000
        return rho_new
    
    def Cp_PH(self,P,H):
        prop_eqn = interp.bisplrep(self.Ps,self.specenth,self.Cp)
        rho_new = interp.bisplev(P,H,prop_eqn)*self.MW/1000
        return rho_new
        
    def rho_PH(self,P,H):
        prop_eqn = interp.bisplrep(self.Ps,self.specenth,self.rho)
        rho_new = interp.bisplev(P,H,prop_eqn)
        return rho_new
        
    def T_PH(self,P,H):
        prop_eqn = interp.bisplrep(self.Ps,self.specenth,self.Ts)
        rho_new = interp.bisplev(P,H,prop_eqn)
        return rho_new
        
    def T_PS(self,P,S):
        prop_eqn = interp.bisplrep(self.Ps,self.specent,self.Ts)
        rho_new = interp.bisplev(P,S,prop_eqn)
        return rho_new
   
        
def getallnames():
    db = df["Critical"]
    listNames = db.Name.to_dict().values() 
    return listNames
    
#if __name__ == "__main__":
#    x1 = Compound('Methane')

meth = Compound('Methane')
air = Compound('Air')
n2 = Compound('Nitrogen')
o2 = Compound('Oxygen')
co2=Compound("Carbon dioxide")
h2o=Compound('Water')

filename5 = "Brayton_calc.xlsx"
thisdir = os.getcwd()
xl = win32com.client.gencache.EnsureDispatch("Excel.Application") #excel has been started
wb5 = xl.Workbooks.Open(thisdir +"/"+ filename5)
xl.Visible = True 
ws5 = wb5.Sheets("Sheet1")

p1 = 15
t1 = 150

class Brayton:
    def __init__(self):
        self.stream1()
        self.stream2()
        self.stream3()
        self.stream4()    
        self.stream5()
        self.stream6()
        self.stream7()
        self.stream8()
        
    def stream1(self):
        P = ws5.Cells(29,2).Value
        T = ws5.Cells(28,2).Value
        self.mass_ch4= 80    #in kg
        self.mol_ch4 = self.mass_ch4/meth.MW   #in mol
        ws5.Cells(27,4).Value=self.mol_ch4
        ws5.Cells(27,6).Value=meth.H_PT(P,T)
        ws5.Cells(27,7).Value=meth.S_PT(P,T)
        ws5.Cells(27,8).Value=meth.CpIG(T)
        
        
    def stream2(self):
        P = ws5.Cells(37,2).Value
        T = ws5.Cells(36,2).Value
        self.mol_O2=10*self.mol_ch4          #in mol O2
        self.mol_N2=self.mol_O2*0.79/0.21    #in mol N2
        
        ws5.Cells(36,4).Value = self.mol_O2 
        ws5.Cells(37,4).Value = self.mol_N2 
        
        ws5.Cells(36,6).Value = o2.H_PT(P,T)
        ws5.Cells(36,7).Value = o2.S_PT(P,T)
        
        ws5.Cells(37,6).Value = n2.H_PT(P,T)
        ws5.Cells(37,7).Value = n2.S_PT(P,T)
        
        ws5.Cells(36,8).Value=o2.CpIG(T)
        ws5.Cells(37,8).Value=n2.CpIG(T)
        
        total_enthalpy= ws5.Cells(36,6).Value + ws5.Cells(37,6).Value
        ws5.Cells(40,6).Value = total_enthalpy
        
        total_entropy = ws5.Cells(36,7).Value + ws5.Cells(37,7).Value  #This gives total entropy of air
        ws5.Cells(40,7).Value = total_entropy
        
    def stream3(self):
        P = ws5.Cells(45,2).Value  
        # total entropy remains constant not the individual entropy
        S_air = ws5.Cells(40,7).Value
        ws5.Cells(48,6).Value = air.H_PS(P,S_air)
        ws5.Cells(44,2).Value = n2.T_PS(P,S_air)
#        S_O2 = ws5.Cells(36,7).Value
#        S_N2 = ws5.Cells(37,7).Value
#        ws5.Cells(45,6).Value = n2.H_PS(P,S_N2)      
#        ws5.Cells(44,6).Value = o2.H_PS(P,S_O2)
        T = ws5.Cells(44,2).Value
        
        ws5.Cells(44,7).Value = o2.S_PT(P,T)
        ws5.Cells(44,6).Value = o2.H_PT(P,T)
        
        ws5.Cells(45,7).Value = n2.S_PT(P,T)
        ws5.Cells(45,6).Value = n2.H_PT(P,T)
        
        ws5.Cells(44,8).Value=o2.CpIG(T)
        ws5.Cells(45,8).Value=n2.CpIG(T)
        
        ws5.Cells(44,4).Value= ws5.Cells(36,4).Value
        ws5.Cells(45,4).Value= ws5.Cells(37,4).Value
        
        ws5.Cells(48,4).Value = ws5.Cells(44,4).Value + ws5.Cells(45,4).Value
        totalmoles= ws5.Cells(32,4).Value+ ws5.Cells(48,4).Value
        x_air = ws5.Cells(48,4)/(totalmoles)
        x_ch4 = ws5.Cells(32,4)/(totalmoles)
        
    def stream4(self):
        ws5.Cells(53,2).Value= ws5.Cells(45,2).Value       
        P= ws5.Cells(53,2).Value       
        ws5.Cells(52,4).Value= ws5.Cells(44,4).Value-2*self.mol_ch4
        ws5.Cells(53,4).Value= ws5.Cells(45,4).Value 
        ws5.Cells(54,4).Value= 2*self.mol_ch4
        ws5.Cells(55,4).Value= self.mol_ch4
        totalmoles= ws5.Cells(52,4).Value+ ws5.Cells(53,4).Value+ws5.Cells(54,4).Value+ws5.Cells(55,4).Value
        x_n2= ws5.Cells(53,4).Value/(totalmoles)
        x_o2= ws5.Cells(52,4).Value/totalmoles
        x_co2= ws5.CelS_o2=x_o2*total_entropy
        S_n2=x_n2*total_entropy
        S_h2o=x_h2o*total_entropy
        S_co2=x_co2*total_entropyls(54,4).Value/totalmoles
        x_h2o=ws5.Cells(55,4).Value/totalmoles
        
    def func(self,T): #in K
        self.T = T
        a=n2.H_PT(15,T)
        b=o2.H_PT(15,T)
        c=co2.H_PT(15,T)
        d=h2o.H_PT(15,T)
        e=air.H_PT(15,T)
        f=meth.H_(15,T)
        func= (x_n2*a+x_o2*b+x_co2*c+x_h2o*d) - (x_air*e+x_ch4*f)
        return func
        T=Tcalc
        ws5.Cells(52,2).Value=T
        ws5.Cells(52,6).Value=x_o2*o2.H_PT(P,T)
        ws5.Cells(53,6).Value=x_n2*n2.H_PT(P,T)
        ws5.Cells(54,6).Value=x_co2*co2.H_PT(P,T)
        ws5.Cells(55,6).Value=x_h2o*co2.H_PT(P,T)
        ws5.Cells(56,6).Value=ws5.Cells(52,6).Value+ws5.Cells(53,6).Value+ws5.Cells(54,6).Value+ws5.Cells(55,6).Value
#        ws5.Cells(52,7).Value=x_o2*o2.S_PT(P,T)
#        ws5.Cells(53,7).Value=x_n2*n2.S_PT(P,T)
#        ws5.Cells(54,7).Value=x_co2*co2.S_PT(P,T)
#        ws5.Cells(55,7).Value=x_h2o*co2.S_PT(P,T)
#        ws5.Cells(56,7).Value=ws5.Cells(52,7).Value+ws5.Cells(53,7).Value+ws5.Cells(54,7).Value+ws5.Cells(55,7).Value
    Tcalc=fsolve(func,600)
    
    def stream5(self):
        T=ws5.Cells(60,2).Value
        P=ws5.Cells(53,2).Value
        ws5.Cells(61,2).Value=P
        ws5.Cells(60,4).Value= ws5.Cells(52,4).Value
        ws5.Cells(61,4).Value= ws5.Cells(53,4).Value 
        ws5.Cells(62,4).Value= ws5.Cells(54,4).Value
        ws5.Cells(63,4).Value= ws5.Cells(55,4).Value
        totalmoles= ws5.Cells(60,4).Value+ ws5.Cells(61,4).Value+ws5.Cells(62,4).Value+ws5.Cells(63,4).Value
        ws5.Cells(64,4).Value = totalmoles
        x_n2= ws5.Cells(61,4).Value/(totalmoles)
        x_o2= ws5.Cells(60,4).Value/totalmoles
        x_co2= ws5.Cells(63,4).Value/totalmoles
        x_h2o=ws5.Cells(62,4).Value/totalmoles
        print (o2.CpIG(T))
        ws5.Cells(60,6).Value=x_o2*o2.H_PT(P,T)
        ws5.Cells(61,6).Value=n2.H_PT(P,T)*x_n2
        ws5.Cells(62,6).Value=h2o.H_PT(P,T)*x_h2o
        ws5.Cells(63,6).Value=co2.H_PT(P,T)*x_co2
        total_enthalpy=ws5.Cells(60,6).Value+ws5.Cells(61,6).Value+ws5.Cells(62,6).Value+ws5.Cells(63,6).Value
        ws5.Cells(64,6).Value=total_enthalpy
        ws5.Cells(60,7).Value=x_o2*o2.S_PT(P,T)
        ws5.Cells(61,7).Value=x_n2*n2.S_PT(P,T)
        ws5.Cells(63,7).Value=x_co2*co2.S_PT(P,T)
        ws5.Cells(62,7).Value=x_h2o*co2.S_PT(P,T)
        total_entropy=ws5.Cells(60,7).Value+ws5.Cells(61,7).Value+ws5.Cells(62,7).Value+ws5.Cells(63,7).Value
        ws5.Cells(64,7).Value=total_entropy
        
    def stream6(self):
        P=ws5.Cells(69,2).Value
        
        ws5.Cells(68,4).Value= ws5.Cells(52,4).Value
        ws5.Cells(69,4).Value= ws5.Cells(53,4).Value 
        ws5.Cells(70,4).Value= ws5.Cells(54,4).Value
        ws5.Cells(71,4).Value= ws5.Cells(55,4).Value
        totalmoles= ws5.Cells(52,4).Value+ ws5.Cells(53,4).Value+ws5.Cells(54,4).Value+ws5.Cells(55,4).Value
        ws5.Cells(72,4).Value = totalmoles
        x_n2= ws5.Cells(53,4).Value/(totalmoles)
        x_o2= ws5.Cells(52,4).Value/totalmoles
        x_co2= ws5.Cells(54,4).Value/totalmoles
        x_h2o=ws5.Cells(55,4).Value/totalmoles
        total_entropy=ws5.Cells(64,7).Value
        ws5.Cells(68,6).Value=o2.H_PS(P,ws5.Cells(60,7).Value)
        ws5.Cells(69,6).Value=n2.H_PS(P,ws5.Cells(61,7).Value)
        ws5.Cells(70,6).Value=h2o.H_PS(P,ws5.Cells(62,7).Value)
        ws5.Cells(71,6).Value=co2.H_PS(P,ws5.Cells(63,7).Value)
        ws5.Cells(72,6).Value=ws5.Cells(68,6).Value+ws5.Cells(69,6).Value+ws5.Cells(70,6).Value+ws5.Cells(71,6).Value
        ws5.Cells(68,7).Value=ws5.Cells(60,7).Value
        ws5.Cells(69,7).Value=ws5.Cells(61,7).Value
        ws5.Cells(70,7).Value=ws5.Cells(62,7).Value
        ws5.Cells(71,7).Value=ws5.Cells(63,7).Value
        
    '''def func1(self,T):
        self.T = T
#       For stream 6 out        
        a=n2.S_PT(3,T)
        b=o2.S_PT(3,T)
        c=h2o.S_PT(3,T)
        d=co2.S_PT(3,T)
#       For stream 5 (inlet to stream 6)
        e=n2.S_PT(15,T)
        f=o2.S_PT(15,T)
        g=h2o.S_PT(15,T)
        h=co2.S_PT(15,T)
        func = x_n2*(a-e) + x_o2*(b-f) + x_h2o*(c-g) + x_co2*(d-h) 
        return func
    Tnew = fsolve(func1,1000)
    
    def stream7(self):
        #Enthalpy balance across heat exchanger
        P= ws5.Cells(69,2).Value
        ws5.Cells(77,2).Value=P
        total_in= ws5.Cells(56,6).Value+ws5.Cells(72,6).Value
        ws5.Cells(80,6).Value=total_in-ws5.Cells(64,6).Value
        totalmoles= ws5.Cells(52,4).Value+ ws5.Cells(53,4).Value+ws5.Cells(54,4).Value+ws5.Cells(55,4).Value
        x_n2= ws5.Cells(53,4).Value/(totalmoles)
        x_o2= ws5.Cells(52,4).Value/totalmoles
        x_co2= ws5.Cells(54,4).Value/totalmoles
        x_h2o=ws5.Cells(55,4).Value/totalmoles
        
    def func2(self,T):
        self.T=T
#       variable_name = variable_stream no"""
        a4=n2.H_PT(15,T)   
        b4=o2.H_PT(15,T)
        c4=co2.H_PT(15,T)
        d4=h2o.H_PT(15,T) 
 
        a7=n2.H_PT(3,T)
        b7=o2.H_PT(3,T)
        c7=co2.H_PT(3,T)
        d7=h2o.H_PT(3,T)
        
        func = (x_n2*(a4+a7) + x_o2*(b4+b7) + x_co2*(c4+c7) + x_h2o*(d4+d7)) - ((x_n2*(a4+a7) + x_o2*(b4+b7) + x_co2*(c4+c7) + x_h2o*(d4+d7))
        return func
        
	T=T2
	ws5.Cells(76,2).Value=T
        P= ws5.Cells(69,2).Value
        ws5.Cells(76,6).Value=o2.H_PT(P,T)
        ws5.Cells(77,6).Value=n2.H_PT(P,T)
        ws5.Cells(78,6).Value=h2o.H_PT(P,T)
        ws5.Cells(79,6).Value=co2.H_PT(P,T)
        total_enthalpy=ws5.Cells(76,6).Value+ws5.Cells(77,6).Value+ws5.Cells(78,6).Value+ws5.Cells(79,6).Value
        ws5.Cells(80,6).Value=total_enthalpy
        ws5.Cells(76,7).Value=o2.S_PT(P,T)
        ws5.Cells(77,7).Value=n2.S_PT(P,T)
        ws5.Cells(78,7).Value=h2o.S_PT(P,T)
        ws5.Cells(79,7).Value=co2.S_PT(P,T)
        total_entropy=ws5.Cells(76,7).Value+ws5.Cells(77,7).Value+ws5.Cells(78,7).Value+ws5.Cells(79,7).Value
        ws5.Cells(80,7).Value=total_entropy
    T2 = fsolve(func2,1000)'''
    
    def stream8(self):
        total_entropy=ws5.Cells(80,7).Value
        ws5.Cells(88,7).Value=total_entropy
        P=ws5.Cells(85,2).Value
        totalmoles= ws5.Cells(52,4).Value+ ws5.Cells(53,4).Value+ws5.Cells(54,4).Value+ws5.Cells(55,4).Value
        x_n2= ws5.Cells(53,4).Value/(totalmoles)
        x_o2= ws5.Cells(52,4).Value/totalmoles
        x_co2= ws5.Cells(54,4).Value/totalmoles
        x_h2o=ws5.Cells(55,4).Value/totalmoles
        total_entropy=ws5.Cells(64,7).Value
        
    def func3(self,T):
        self.T=T
        P7 = 3 #bar
        P8 = 1 #bar
        a7=n2.H_PT(P7,T)
        b7=o2.H_PT(P7,T)
        c7=co2.H_PT(P7,T)
        d7=h2o.H_PT(P7,T)
        a8=n2.H_PT(P8,T)
        b8=o2.H_PT(P8,T)
        c8=co2.H_PT(P8,T)
        d8=h2o.H_PT(P8,T)
        func = x_n2*(a8-a7) + x_o2*(b8-b7) + x_co2*(c8-c7) + x_h2o*(d8-d7)
        return func
        
        P= ws5.Cells(85,2).Value
        ws5.Cells(84,6).Value=o2.H_PT(P,T3)
        ws5.Cells(85,6).Value=n2.H_PT(P,T3)
        ws5.Cells(86,6).Value=h2o.H_PT(P,T3)
        ws5.Cells(87,6).Value=co2.H_PT(P,T3)
        total_enthalpy=ws5.Cells(84,6).Value+ws5.Cells(85,6).Value+ws5.Cells(86,6).Value+ws5.Cells(87,6).Value
        ws5.Cells(88,6).Value=total_enthalpy
        ws5.Cells(84,7).Value=o2.S_PT(P,T3)
        ws5.Cells(85,7).Value=n2.S_PT(P,T3)
        ws5.Cells(86,7).Value=h2o.S_PT(P,T3)
        ws5.Cells(87,7).Value=co2.S_PT(P,T3)
        total_entropy=ws5.Cells(84,7).Value+ws5.Cells(85,7).Value+ws5.Cells(86,7).Value+ws5.Cells(87,7).Value
        ws5.Cells(88,7).Value=total_entropy
    T3 = fsolve(func3,1000)

x = Brayton()
        
