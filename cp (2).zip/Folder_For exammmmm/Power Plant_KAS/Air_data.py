

import numpy as np
import scipy.interpolate as interp
import win32com.client
import scipy,os
import pandas
import xlrd
filename='Air.xlsx'
thisdir=os.getcwd()
x1=win32com.client.gencache.EnsureDispatch("Excel.Application")
wb=x1.Workbooks.Open(thisdir + "/" + filename)
x1.Visible=True


sheet=wb.Sheets("Data")

'''P=np.hstack(np.array(sheet.Range('A2:A101').Value))
T=np.hstack(np.array(sheet.Range('B2:B101').Value))
H=np.hstack(np.array(sheet.Range('D2:D101').Value))
S=np.hstack(np.array(sheet.Range('E2:E101').Value))
Cp=np.hstack(np.array(sheet.Range('F2:F101').Value))
#Cv=np.hstack(np.array(sheet.Range('G2:G101').Value))
rho=np.hstack(np.array(sheet.Range('C2:C101').Value))
inter_s=interp.bisplrep(P,T,S)  
inter_h=interp.bisplrep(P,T,H) 
inter_cp=interp.bisplrep(P,T,Cp)
#inter_cv=interp.bisplrep(P,T,Cv)''' 

if os.path.isdir("Data"):
    os.chdir("Data")
xl_file = pandas.ExcelFile(filename)
os.chdir(thisdir)
df = {}  #dataframe or dict of dataframe
df["Data"] = xl_file.parse("Data")
Temp=scipy.ones(100)
Pres=scipy.ones(100)
Enthalpy=scipy.ones(100)
Entropy=scipy.ones(100)
Dens=scipy.ones(100)
Cp=scipy.ones(100)
#Cv=scipy.ones(sheet.nrows-1)
#Air = xlrd.open_workbook("Air")
#data_sheet = Air.get_sheet(0) 
#rowcountAir = data_sheet.nrows
db=df["Data"]
for j in range(1,100):
    Temp[j]=db.Temperature.values[j]
    Pres[j]=db.Pressure.values[j]
    Dens[j]=db.Density.values[j]
    Enthalpy[j]=db.Specific_Enthalpy.values[j]
    Entropy[j]=db.Specific_Entropy.values[j]
    Cp[j]=db.Cp.values[j]
    #Cv[j]=db.Cv.values[j]
def enthalpy(T,P):
    Enthalinterp=scipy.interpolate.bisplrep(Temp,Pres,Enthalpy)
    Enthalnew=scipy.interpolate.bisplev(T,P,Enthalinterp)
    return Enthalnew
def entropy(T,P):
    Entropyinterp=scipy.interpolate.bisplrep(Temp,Pres,Entropy)
    Entropynew=scipy.interpolate.bisplev(T,P,Entropyinterp)
    return Entropynew 
    print Entropynew 