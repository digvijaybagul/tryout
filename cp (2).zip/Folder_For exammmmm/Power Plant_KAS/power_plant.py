# -*- coding: utf-8 -*-
"""
Created on Mon Aug 10 22:29:00 2015

@author: KasturiSarang
"""

import win32com.client
import scipy,os
import numpy as np
import pandas
import scipy.optimize as opt
from scipy import interpolate
import Nitrogen_data as N2
import co2_data as CO2
import Oxygen_data as O2
import Air_data as air
import Methane_data as CH4
import Water_data as water
import verify
from scipy import integrate
n=verify.Compound("Nitrogen")  #according to xcel file of perry 
o=verify.Compound('Oxygen')
class Data:
    def __init__(self,Name):
        self.name= Name
    
    
o1=Data(air)
n1=Data(N2)
carbondioxide=Data(CO2)
water=Data(water)
methane=Data(CH4) 

def intg(T):
    q=n.CpIG(T+273)/(T+273)
    return q 
print intg(30)     
def solve_air(T,P):
    if T>1000:
        N_s=n.Sf+integrate.quad(intg,n.Tf,T+273)[0]
        N_h=n.Hf+integrate.quad(n.CpIG,n.Tf,T+273)[0]
        O_s=o.Sf+integrate.quad(intg,o.Tf,T+273)[0]
        O_h=o.Hf+integrate.quad(o.CpIG,o.Tf,T+273)[0]
    elif T<1000:
        N_s=N2.entropy(P,T+273)
        N_h=N2.enthalpy(P,T+273)
        O_s=O2.entropy(P,T+273)
        O_h=O2.enthalpy(P,T+273)
    x=0.79*N_s*28 + 0.21*O_s*32-151.62
    return x
def solve_air_H(T,P):
    if T>1000:
        N_s=n.Sf+integrate.quad(intg,n.Tf,T+273)[0]
        N_h=n.Hf+integrate.quad(n.CpIG,n.Tf,T+273)[0]
        O_s=o.Sf+integrate.quad(intg,o.Tf,T+273)[0]
        O_h=o.Hf+integrate.quad(o.CpIG,o.Tf,T+273)[0]
    elif T<1000:
        N_s=N2.entropy(P,T+273)
        N_h=N2.enthalpy(P,T+273)
        O_s=O2.entropy(P,T+273)
        O_h=O2.enthalpy(P,T+273)
    
    x=0.79*N_h*28 + 0.21*O_h*32
    return x
    
z=solve_air(30,1)
print z

def error(T,P):
    c=solve_air(T,P)-z
    return c
   
    
T=30
soln=opt.leastsq(error,T,10)[0]
print soln

def soln2(T,P):
    if T>1000:
        N_s=n.Sf+integrate.quad(intg,n.Tf,T+273)[0]
        N_h=n.Hf+integrate.quad(n.CpIG,n.Tf,T+273)[0]
        
    elif T<1000:
        N_s=n1.entropy(P,T)
        N_h=n1.enthalpy(P,T)
       
    y=N_h*28 
    return y
    
def solo2(T,P):
    if T>1000:        
        O_s=o.Sf+integrate.quad(intg,o.Tf,T+273)[0]
        O_h=o.Hf+integrate.quad(o.CpIG,o.Tf,T+273)[0]
    elif T<1000:       
        O_s=o1.entropy(P,T)
        O_h=o1.enthalpy(P,T)
    y=O_h*32
    return y
 

n=(10.476)*(solair_H(soln,10))+met.enthalpy(10,30)*16 


def err(T,P): 
    nit=8.276*soln2(T,P)
    oxy=0.2*solo2(T,P)
    carb=1*car.enthalpy(P,T)
    water=2*wat.enthalpy(P,T)
    out=nit+oxy+carb+water
    z=out-n
    return z

solution=opt.leastsq(err,T,10)[0]
print solution 

