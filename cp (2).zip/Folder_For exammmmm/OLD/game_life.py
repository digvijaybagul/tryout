# -*- coding: utf-8 -*-
"""
Created on Mon Jan 19 19:03:58 2015

@author: KasturiSarang
"""

import numpy as np
import matplotlib.pyplot as plt
row=50
col=50

z=np.random.randint(2,size=(row,col))

            
f=np.random.randint(1,size=(row,col))

fig = plt.figure()
ax=fig.add_subplot(111); fig.show()
number=0

while (number<15):
    for x in range(1,row-1):
        for y in range(1,col-1):
                 f[x,y]=z[x-1,y-1]+z[x-1,y]+z[x-1,y+1]+z[x,y-1]+z[x,y+1]+z[x+1,y-1]+z[x+1,y]+z[x+1,y+1]
   

    for x in range(1,row-1):
        for y in range(1,col-1):
            if z[x,y]==1:
                if f[x,y] > 3 or f[x,y] < 2:
                    z[x,y]=0
            elif z[x,y]==0 and f[x,y]==3:
                    z[x,y]=1
    print z
    ax.imshow(z,interpolation='nearest', cmap=plt.cm.flag_r)
    plt.xticks([]), plt.yticks([])
    plt.pause(1)

    number=number+1
print z


