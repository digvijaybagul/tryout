# -*- coding: utf-8 -*-
"""
Created on Tue Jan 27 11:45:12 2015

@author: vhd
"""

class Fluid:
    def __init__(self,fluidprops):
        self.props=fluid properties
        self.massflowrate
        self.temperature
    def H(self,T,P):
        Psat=self.props.Psat(T)
        if P<Psat:
            Cp=self.props.CpL
            HfL=self.props.Hf-self.props.Hvap(self.props.Tf)
            H=HfL+scipy.integrate.quad(Cp,Tf,T)
            return H
        else:
def Re(self,dh):
