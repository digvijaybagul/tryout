# -*- coding: utf-8 -*-
"""
Created on Tue Jan 27 11:57:41 2015

@author: vhd
"""

import scipy
from Hex import DPHex
from fluid import Fluid,Op_cond
import water,benzene
import tri_dimen
import op_cond
Water=Fluid(Compounds.water,Op_cond.annulus-flowrate,op_cond.annulusTemp)
Benzene=Fluid(Compounds.benzene,Op_cond.pipeflow,op_cond.pipeTemp)
dphex1=DPHex(op_cond.di,op_cond.do,op_cond.L,water,benzene)
dphex1=DPHex(op_cond.di,op_cond.do,op_cond.L,water,benzene)


