# -*- coding: utf-8 -*-
"""
Created on Sat Jan 17 23:02:15 2015

@author: KasturiSarang
"""
import numpy as np
from matplotlib import pyplot as plt
from matplotlib import animation
from random import randint

arraySize = 50
Z = np.array([[randint(0, 1) for x in range(arraySize)] for y in range(arraySize)])

def computeNeighbours(Z):
    rows, cols = len(Z), len(Z[0])
    N = np.zeros(np.shape(Z))

for x in range(rows):
    for y in range(cols):
        Q = [q for q in [x-1, x, x+1] if ((q >= 0) and (q < cols))]
        R = [r for r in [y-1, y, y+1] if ((r >= 0) and (r < rows))]
        S = [Z[q][r] for q in Q for r in R if (q, r) != (x, y)]
        N[x][y] = sum(S)
        return N
        
def iterate(Z):
    Zprime = Z.copy()
    rows, cols = len(Zprime), len(Zprime[0])
    N = computeNeighbours(Zprime)

for x in range(rows):
    for y in range(cols):
        if Zprime[x][y] == 1:
            if (N[x][y] < 2) or (N[x][y] > 3):
                Zprime[x][y] = 0
            else:
                if (N[x][y] == 3):
                    Zprime[x][y] = 1
fig = plt.figure()

Zs = [Z]
ims = []

for i in range(0, 100):
    im = plt.imshow(Zs[len(Zs)-1], interpolation = 'nearest', cmap='binary')
    ims.append([im])
    Zs.append(iterate(Zs[len(Zs)-1]))

ani = animation.ArtistAnimation(fig, ims, interval=250, blit=True)
plt.show()