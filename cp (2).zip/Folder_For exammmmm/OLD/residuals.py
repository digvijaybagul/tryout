# -*- coding: utf-8 -*-
"""
Created on Tue Jan 20 13:26:14 2015

@author: vhd
"""

def residuals(T,obj):
        n=obj.n
        Thin=obj.Thin
        Tcin=obj.Tcin
        Th=T[:n]
        Tc=T[n:]
        dA=obj.dA
    return err