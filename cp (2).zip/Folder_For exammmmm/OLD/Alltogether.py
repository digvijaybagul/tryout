# -*- coding: utf-8 -*-
"""
Created on Tue Jan 27 11:58:15 2015

@author: vhd
"""

import scipy
from Heat_Exchangers import DPHex   #from file name Hex.py import class DPHex
from Fluids import Fluid  
import Compounds
import op_cond   #operation condition ; also a container.
Water=Fluid(Compounds.compounds["water"],op_cond.annulusflowrate,op_cond.annulusTemp)   #Fluid takes one argument so water
#In future i may need more fluid props. so op_cond does this for u
Benzene=Fluid(Compounds.compounds["benzene"],op_cond.pipeflowrate,op_cond.pipeTemp)
dphex1=DPHex(op_cond.di,op_cond.do,op_cond.L,Compounds.compounds["Water"],Compounds.compounds["benzene"])
dphex2=DPHex(op_cond.di,op_cond.do,op_cond.L,Compounds.compounds["benzene'"],Compounds.compounds["Water"])
print dphex2































