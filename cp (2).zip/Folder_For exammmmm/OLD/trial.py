# -*- coding: utf-8 -*-
"""
Created on Sat Jan 17 21:59:19 2015

@author: KasturiSarang
"""
import random 
a=random.random((2,3))
print a
