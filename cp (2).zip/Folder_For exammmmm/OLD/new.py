# -*- coding: utf-8 -*-
"""
Created on Sun Jan 18 18:23:42 2015

@author: KasturiSarang
"""
import scipy
import scipy.optimize.leastsq
def cp(T):
    y=4.184+((10^(-4))*T)+((10^(-6))*T^2)+((10^(-9))*T^3)
    return y
Thin=373;
Tcin=303;
n=10;mh=1; mc=2; U=300; A=10;
Thguess=scipy.array(n*[Thin])
Tcguess=scipy.array(n*[Tcin])
Tguess=scipy.concatenate((Thguess,Tcguess))
def error(T,U,mh,mc,Thin,Tcin):
    n=len(T)/2
    Th=T[:n]
    Tc=T[n:]
    dA=A/(n-1)
    error0=((Th[1]-Thin)/2*dA)+((U*(Th[1]+Thin-Tc[1]-Tcin))/(mh*cp((Th[1]+Thin)/2)))
    error1=((Tc[1]-Tcin)/2*dA)+((U*(Th[1]+Thin-Tc[1]-Tcin))/(mc*cp((Tc[1]+Tcin)/2)))
solution=scipy.optimize.leastsq(error0,error1,Tguess,args=(U,mh,mc,Thin,Tcin,A))
