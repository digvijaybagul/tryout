# -*- coding: utf-8 -*-
"""
Created on Tue Jan 20 12:31:00 2015

@author: vhd
"""
import scipy
import scipy.optimize as opt
Thin=373; #kelvin
Tcin=303;#kelvin
n=10;
mh=1; #kg/s 
mc=2; #kg/s
U=300; #W/m2K 
A=10; #m2
def CpH(T):
    CpH=(4.184+(10**-9)*T**3+(10**-6)*T**2+(10**-4)*T)*1000
    return CpH
    
def CpC(T):
    CpC=(4.184+(10**-9)*T**3+(10**-6)*T**2+(10**-4)*T)*1000
    return CpC

def residuals(T,obj):
    n=obj.n
    Thin=obj.Thin
    Tcin=obj.Tcin
    Th=T[:n]
    Tc=T[n:]
    dA=obj.dA
class DPHEx:
    def __init__(self,A,U,mh,Thin,mc,Tcin,n,CpH,CpC):
        self.Area=A
        self.U=U
        self.set_hex(mh,Thin,mc,Tcin)
        self.set_grid(n)
        self.set_CpH(CpH); self.set_CpC(CpC)
    def set_hex(self,mh,Thin,mc,Tcin):
        self.mh=mh
        self.mc=mc
        self.Thin=Thin
        self.Tcin=Tcin
    def set_grid(self,n):
        self.n=n
        self.Th=scipy.ones(n)*self.Thin
        self.Tc=scipy.ones(n)*self.Tcin
        self.dA=self.A/(n-1)
        self.Tguess=scipy.concatenate((self.Th,self.Tc))

    def set_CpH(self,f):
        self.CpH=f
    def set_CpC(self,f):
        self.CpC=f
    def solve(self,f):
        Tguess=self.Tguess
        Tsoln=opt.leastsq(residuals,Tguess,args=(self))
        self.Th=Tsoln[:self.n]
        self.Tc=Tsoln[self.n:]
        self.Th[0]=self.Thin
        self.Tc[-1]=self.Tcin
    def check(self):
        n=10;
        hex=DPHEx(A,U,mh,mc,Thin,Tcin,n,CpH,CpC)
        listn=range(10,100,20)
        listerr=[]
        for n in listn:
            hex.set_grid(n)
            hex.solve()
            err=hex.check()
            listerr += [err]
  
   
    
     
         