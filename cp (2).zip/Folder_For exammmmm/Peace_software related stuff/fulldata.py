# -*- coding: utf-8 -*-
"""
Created on Sun Aug 02 21:38:10 2015

@author: KasturiSarang
"""

import win32com.client
import scipy,os
filename="n2.xlsx"
thisdir=os.getcwd()
xl=win32com.client.gencache.EnsureDispatch("Excel.Application")
wb=xl.Workbooks.Open(thisdir+"/"+filename)
xl.Visible=True
sheet=wb.Sheets("Data")

import selenium
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
r=0
Pmin= 1.0
Pmax=1000.0
Tmin=0.0
Tmax=1000.0
T=scipy.linspace(Tmin,Tmax,20)
P=scipy.linspace(Pmin,Pmax,20)
#print P
browser = webdriver.Firefox()
for p in range(20):
    for t in range(20):
        
        browser.get("http://www.peacesoftware.de/einigewerte/einigewerte_e.html")

        elem = browser.find_element_by_link_text("Nitrogen - N2")
        elem.click()
        elemP = browser.find_element_by_name("druck")
        elemT = browser.find_element_by_name("temperatur")

        elemP.send_keys(str(P[p]))
        elemT.send_keys(str(T[t]))
        elemCalc = browser.find_element_by_name("Submit")
        elemCalc.click()
    
        elemTables = browser.find_elements_by_xpath("//table") #get tables
        body=browser.find_elements_by_tag_name('tbody')
        rows=body[1].find_elements_by_tag_name('tr')
        #print len(rows)
        name=[]
        value=[]
        unit=[]
        for j in range (1,len(rows)):
            
            td=rows[j].find_elements_by_tag_name('td')
            name.append(td[0].text)
            value.append(td[1].text)
            unit.append(td[2].text)
            
        
        
        for i in range((len(rows)-1)):
            sheet.Cells(t+2,i+1).Value=value[i]
            sheet.Cells(1,i+1).Value=name[i]
            sheet.Cells(len(rows)+2,i+1).Value=unit[i]
r=r+20
'''for i in range(1,18):
            td = rows[i].find_elements_by_tag_name('td')
            name=(td[0].text)
            sheet.Range(sheet.Cells(1,i)).Value= name
            value=(td[1].text)
            sheet.Range(sheet.Cells(t+2,i)).Value= value
            unit=(td[2].text)
            sheet.Range(sheet.Cells(20,i)).Value= unit
    r=r+10
sheet.Range(sheet.Cells(1,1),sheet.Cells(1,17)).Value= name
    sheet.Range(sheet.Cells(p+2,1),sheet.Cells(p+2,17)).Value= value
    sheet.Range(sheet.Cells(13,1),sheet.Cells(13,17)).Value= unit'''
