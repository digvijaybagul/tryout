# -*- coding: utf-8 -*-
"""
Created on Mon Aug 10 21:57:45 2015

@author: KasturiSarang
"""

import win32com.client
import scipy,os
filename='N2.xlsx'
thisdir=os.getcwd()
xl=win32com.client.gencache.EnsureDispatch("Excel.Application")
wb=xl.Workbooks.Open(thisdir+"/"+filename)
xl.Visible=True
sheet=wb.Sheets("Data")
import scipy as sc
import selenium
import numpy as np
import scipy
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
browser = webdriver.Firefox()
q=0
Pmin=1
Pmax=999
Tmin=200
Tmax=999
T=sc.linspace(Tmin,Tmax,10)
P=sc.linspace(Pmin,Pmax,10)


for k in range(10):
    for j in range(10):
        browser.get("http://www.peacesoftware.de/einigewerte/einigewerte_e.html")
    
        elem = browser.find_element_by_link_text("Nitrogen - N2")
        elem.click()
    
        elemP = browser.find_element_by_name("druck")
        elemT = browser.find_element_by_name("temperatur")
    
    
        elemP.send_keys(str(P[k]))
        elemT.send_keys(str(T[j]))
        elemCalc = browser.find_element_by_name("Submit")
        elemCalc.click()
        
        body=browser.find_elements_by_tag_name('tbody')
        rows=body[1].find_elements_by_tag_name('tr')
        name=[]
        value=[]
        unit=[]
        for i in range (1,18):
            
            columns1=rows[i].find_elements_by_tag_name('td')
            name.append(columns1[0].text)
            value.append(columns1[1].text)
            unit.append(columns1[2].text)
            
        
        
        for i in range(17):
            
            sheet.Cells((j+q+2),i+1).Value=value[i]
            sheet.Cells(1,i+1).Value=name[i]
    q=q+10
    

'''from scipy import interpolate

p=sheet.Range('C2:C101').Value
t=sheet.Range('D2:D101').Value
h=sheet.Range('F2:F101').Value
s=sheet.Range('G2:G101').Value
P=np.hstack(np.array(p))
T=np.hstack(np.array(t))
H=np.hstack(np.array(h))
S=np.hstack(np.array(s))



P1=P.reshape(10,10)
T1=T.reshape(10,10)
H1=H.reshape(10,10)
S1=S.reshape(10,10)
#calc=interpolate.bisplrep(P1,T1,H1)
#final=interpolate.bisplev(1,100,calc)



calc=interpolate.SmoothBivariateSpline(P,T,H)
f=calc(1,500)
print f
'''