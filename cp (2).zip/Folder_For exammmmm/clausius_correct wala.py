# -*- coding: utf-8 -*-
"""
Created on Fri Dec 04 19:49:47 2015

@author: KasturiSarang
"""

import perrysdata as pd
import pandas
import scipy as sc
import numpy as np
import matplotlib.pyplot as plt

dicterr={}
dictX ={}
dictY={}
err=[]
for i in range(0,226): 
    a=pd.df["Hvap"]
    b=pd.PerryCompound(a.Name[i])
    comp = a[a.Name == b.Name]
    Tmin=comp.Tmin[i]
#if (comp.Tmax[i]-60)>Tmin:
#Tmax=comp.Tmax[i]-60
#else:
#Tmax=comp.Tmax[i]
    Tmax=comp.Tmax[i]
T=sc.arange(Tmin,Tmax,0.1)
P=b.Pvap(T) 
R= 8314.4598
lnP=sc.log(P)
dlnP=np.gradient(lnP)
dT=np.gradient(T)
X=dlnP/dT
Y=b.Hvap(T)/(R*T*T)
err1=(abs(X-Y))/X
err2=np.average(err1)
print (i,b.Name,err2)
err.append(err2)
dicterr[err2]=a.Name[i]
dictX[err2]=X
dictY[err2]=Y
print ('The 36 compounds are:')
err.sort()
ele=err[:36]
for t in ele:
    print (dicterr[t],t)
'''
x=dictX[t]
y=dictY[t]
plt.clf()
plt.plot(x,y,'r')
plt.plot(x,x,'b')
plt.ylabel('delH/R*T*T')
plt.xlabel('dlnP/dT')
plt.title(dicterr[t])
plt.axis('equal')
plt.show()
plt.pause(0.5)
'''
